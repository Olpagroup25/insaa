# Copyright 2026 Olpa Group
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)
{
    "name": "Reparto",
    "version": "18.0.1.0.0",
    "license": "AGPL-3",
    "author": "Olpa Group",
    "application": True,
    "summary": "Control de playa, movimientos por cliente y liquidación diaria "
    "de reparto sobre la base OCA field-service.",
    "depends": [
        "fieldservice_route",
        "fieldservice_recurring",
        "fieldservice_stock",
        "stock",
        "fleet",
        "hr",
        "mail",
        # Paso 1.12: se formaliza como dependencia declarada — el
        # controlador ya usaba account.payment desde antes (_ultima_cobranza),
        # sin declararlo en el manifest.
        "account",
        # feature-formulario-alta: el formulario público de alta usa
        # website.layout y rutas website=True.
        "website",
    ],
    "data": [
        "security/insa_reparto_security.xml",
        "security/ir.model.access.csv",
        "data/ir_cron.xml",
        "views/fsm_route_views.xml",
        "views/insa_repartidor_credencial_views.xml",
        "views/insa_control_playa_views.xml",
        "views/insa_liquidacion_views.xml",
        "views/insa_ajuste_inventario_views.xml",
        "views/menu_reparto.xml",
        "views/fsm_route_dayroute_views.xml",
        "views/insa_movimiento_cliente_views.xml",
        "views/product_template_views.xml",
        "views/res_partner_views.xml",
        "views/hr_employee_views.xml",
        "views/insa_city_views.xml",
        "views/insa_street_views.xml",
        "views/insa_registration_templates.xml",
    ],
    "installable": True,
    "post_init_hook": "_renombrar_secuencia_hoja_ruta",
}
