# Copyright 2026 Olpa Group
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)
"""Los 7 casos de test obligatorios del documento D1 (§10 /
Hoja_de_Ruta_Flujo_Punta_a_Punta.md, sección 7 del prompt de
implementación), tomados textualmente de la reunión del 18/07/2026.

Nota: esta suite se escribió sin una instancia de Odoo corriendo en la
sesión de desarrollo — no se ejecutó. Correr con:

    odoo-bin -d <db> -i insa_reparto --test-enable --stop-after-init \
        --test-tags insa_reparto

antes de dar por buena la entrega.
"""
from datetime import date

from odoo.exceptions import UserError
from odoo.tests import TransactionCase, tagged


@tagged("post_install", "-at_install")
class TestD1Casos(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        # fsm.route._default_team_id revienta si no hay ningún fsm.team.
        if not cls.env["fsm.team"].search([], limit=1):
            cls.env["fsm.team"].create({"name": "Equipo Test D1"})

        cls.envase_sifon = cls._crear_envase("Envase Sifón 1 1/4")
        cls.sifon = cls._crear_articulo("Sifón 1 1/4", cls.envase_sifon)

        cls.envase_bidon15 = cls._crear_envase("Envase Bidón 15")
        cls.bidon15 = cls._crear_articulo("Bidón de 15", cls.envase_bidon15)

        cls.envase_bidon20 = cls._crear_envase("Envase Bidón 20")
        cls.bidon20_comun = cls._crear_articulo("Bidón de 20 común", cls.envase_bidon20)
        cls.bidon20_canilla = cls._crear_articulo(
            "Bidón de 20 con canilla", cls.envase_bidon20
        )

    @classmethod
    def _crear_envase(cls, name):
        return cls.env["product.template"].create(
            {"name": name, "es_envase": True, "is_storable": True}
        )

    @classmethod
    def _crear_articulo(cls, name, envase):
        return cls.env["product.template"].create(
            {
                "name": name,
                "es_retornable": True,
                "envase_id": envase.id,
                "is_storable": True,
            }
        )

    def _crear_cliente(self, name):
        # type=fsm_location dispara la creación automática de la
        # ubicación de stock propia del cliente (res_partner.py) y del
        # fsm.location asociado (OCA fieldservice).
        return self.env["res.partner"].create({"name": name, "type": "fsm_location"})

    def _crear_dayroute(self, numero_reparto):
        # numero_reparto >= 900 a propósito: INSA usa 1-17 en la vida real
        # (y en cualquier dato de demo/prueba que se cargue a mano), así que
        # el rango 900+ evita chocar con el unique constraint de fsm.route.
        route = self.env["fsm.route"].create(
            {
                "name": "Ruta test %s" % numero_reparto,
                "max_order": 50,
                "numero_reparto": numero_reparto,
            }
        )
        fecha = date.today()
        day = self.env.ref("fieldservice_route.fsm_route_day_%d" % fecha.weekday())
        route.day_ids = [(6, 0, [day.id])]
        return self.env["fsm.route.dayroute"].create(
            {"route_id": route.id, "date": fecha}
        )

    def _control_playa(self, dayroute, tipo, lineas):
        return self.env["insa.control.playa"].create(
            {
                "hoja_ruta_id": dayroute.id,
                "tipo": tipo,
                "linea_ids": [(0, 0, linea) for linea in lineas],
            }
        )

    def test_ct01_ct02_liquidacion_articulos(self):
        """CT-01 (sin diferencia) y CT-02 (con diferencia), tal como
        aparecen juntos en el ejemplo real de la reunión (Reparto 2,
        día martes)."""
        dayroute = self._crear_dayroute(901)

        self._control_playa(
            dayroute,
            "salida",
            [
                {"product_id": self.sifon.id, "cantidad": 150},
                {"product_id": self.bidon15.id, "cantidad": 42},
            ],
        )
        self.assertEqual(dayroute.state, "en_reparto")  # RN-01

        self._control_playa(
            dayroute,
            "entrada",
            [
                {"product_id": self.sifon.id, "cantidad": 63},
                {"product_id": self.bidon15.id, "cantidad": 9},
            ],
        )

        cliente = self._crear_cliente("Cliente CT01-CT02")
        self.env["insa.movimiento.cliente"].create(
            {
                "hoja_ruta_id": dayroute.id,
                "partner_id": cliente.id,
                "linea_articulo_ids": [
                    (0, 0, {"product_id": self.sifon.id, "cantidad": 87, "precio_unitario": 100}),
                    (0, 0, {"product_id": self.bidon15.id, "cantidad": 27, "precio_unitario": 100}),
                ],
            }
        )

        dayroute.action_recalcular_liquidacion()

        liq_sifon = dayroute.liquidacion_articulo_ids.filtered(lambda l: l.product_id == self.sifon)
        liq_bidon = dayroute.liquidacion_articulo_ids.filtered(lambda l: l.product_id == self.bidon15)

        # CT-01 — sin diferencia
        self.assertEqual(liq_sifon.teorico, 87)
        self.assertEqual(liq_sifon.registrado, 87)
        self.assertEqual(liq_sifon.diferencia, 0)

        # CT-02 — con diferencia
        self.assertEqual(liq_bidon.teorico, 33)
        self.assertEqual(liq_bidon.registrado, 27)
        self.assertEqual(liq_bidon.diferencia, 6)

    def test_ct03_venta_simple(self):
        """Galván, Brenda: 3 bidones de 20 con canilla, sin cobro →
        íconos ✔️🛒, sin ícono de envase ni de pesos."""
        dayroute = self._crear_dayroute(902)
        self._control_playa(dayroute, "salida", [{"product_id": self.bidon20_canilla.id, "cantidad": 10}])

        cliente = self._crear_cliente("Galván, Brenda")
        mov = self.env["insa.movimiento.cliente"].create(
            {
                "hoja_ruta_id": dayroute.id,
                "partner_id": cliente.id,
                "linea_articulo_ids": [
                    (0, 0, {"product_id": self.bidon20_canilla.id, "cantidad": 3, "precio_unitario": 500})
                ],
            }
        )

        self.assertTrue(mov.visitado)
        self.assertTrue(mov.tiene_venta)
        self.assertFalse(mov.tiene_mov_envase)
        self.assertFalse(mov.tiene_cobro)
        self.assertEqual(mov.iconos_visita, "✔️ 🛒")

    def test_ct04_venta_mas_prestamo(self):
        """Sosa, Mario: 2 bidones de 20 vendidos + 2 prestados →
        íconos ✔️🛒➡️; el cuadro de envases baja la entrada teórica en 2."""
        dayroute = self._crear_dayroute(903)
        self._control_playa(dayroute, "salida", [{"product_id": self.bidon20_comun.id, "cantidad": 10}])

        cliente = self._crear_cliente("Sosa, Mario")
        mov = self.env["insa.movimiento.cliente"].create(
            {
                "hoja_ruta_id": dayroute.id,
                "partner_id": cliente.id,
                "linea_articulo_ids": [
                    (0, 0, {"product_id": self.bidon20_comun.id, "cantidad": 2, "precio_unitario": 500})
                ],
                "linea_envase_ids": [
                    (0, 0, {"product_id": self.bidon20_comun.id, "tipo": "prestamo", "cantidad": 2})
                ],
            }
        )

        self.assertTrue(mov.tiene_venta)
        self.assertTrue(mov.tiene_mov_envase)
        self.assertEqual(mov.iconos_visita, "✔️ 🛒 ➡️")

        self._control_playa(dayroute, "entrada", [{"product_id": self.bidon20_comun.id, "cantidad": 8}])
        dayroute.action_recalcular_liquidacion()

        liq_envase = dayroute.liquidacion_envase_ids.filtered(lambda l: l.product_id == self.bidon20_comun)
        # entrada_teorica = salida(10) - prestamos(2) + devoluciones(0) = 8
        self.assertEqual(liq_envase.entrada_teorica, 8)

    def test_ct05_deuda_envases(self):
        """Banco de la Nación Argentina · bidón de 20 común · consumo
        habitual 3 · saldo 10 → deuda = 7.

        Nota: el checkpoint del 06/08/2026 decidió mantener el campo
        tolerancia_envase (%) en vez de pasar a consumo habitual exacto
        (RN-16). Para reproducir el número literal de la reunión, acá
        se fuerza tolerancia = 0% en el producto de test — es el
        comportamiento que da permitido = consumo habitual exacto."""
        cliente = self._crear_cliente("Banco de la Nación Argentina")
        self.bidon20_comun.tolerancia_envase = 0.0

        camion = self.env["stock.warehouse"].search([], limit=1).lot_stock_id
        self.env["stock.quant"]._update_available_quantity(
            self.envase_bidon20.product_variant_id, cliente.property_stock_customer, 10
        )
        # el quant nace también en el camión por la búsqueda anterior en
        # algunas versiones; no afecta el cálculo, que solo mira la
        # ubicación del cliente.
        self.assertTrue(camion)

        saldo = self.env["insa.saldo.envase"].create(
            {
                "partner_id": cliente.id,
                "product_id": self.bidon20_comun.id,
                "consumo_promedio": 3,
            }
        )

        self.assertEqual(saldo.saldo, 10)
        self.assertEqual(saldo.permitido, 3)
        self.assertEqual(saldo.cantidad_a_recuperar, 7)

    def test_ct06_salida_entrada_prestamo_imputado(self):
        """Distribuidor 9 (Matías Jaime): sale con 20 envases llenos,
        vuelve con 15 llenos → vendió 5 · de esos, trae 3 vacíos y 2
        no → 2 envases quedaron prestados, imputados a Nicolás
        Alessandrini, cuyo saldo sube en 2."""
        dayroute = self._crear_dayroute(904)
        self._control_playa(dayroute, "salida", [{"product_id": self.bidon20_comun.id, "cantidad": 20}])

        nicolas = self._crear_cliente("Nicolás Alessandrini")
        mov = self.env["insa.movimiento.cliente"].create(
            {
                "hoja_ruta_id": dayroute.id,
                "partner_id": nicolas.id,
                "linea_envase_ids": [
                    (0, 0, {"product_id": self.bidon20_comun.id, "tipo": "prestamo", "cantidad": 2})
                ],
            }
        )
        mov.action_confirmar()
        self.assertTrue(mov.envase_movido)

        self._control_playa(
            dayroute, "entrada", [{"product_id": self.bidon20_comun.id, "cantidad": 15, "cantidad_vacia": 3}]
        )
        dayroute.action_recalcular_liquidacion()

        liq = dayroute.liquidacion_envase_ids.filtered(lambda l: l.product_id == self.bidon20_comun)
        self.assertEqual(liq.entrada_teorica, 18)  # 20 - 2 préstamos + 0 devoluciones
        self.assertEqual(liq.entrada_real, 18)  # 15 llenos + 3 vacíos
        self.assertEqual(liq.diferencia, 0)  # conciliado: el préstamo explica la diferencia

        saldo = self.env["insa.saldo.envase"].create(
            {"partner_id": nicolas.id, "product_id": self.bidon20_comun.id}
        )
        self.assertEqual(saldo.saldo, 2)

    def test_ct07_cierre_con_diferencia(self):
        """Reparto con diferencia de 6 bidones sin resolver → usuario
        común bloqueado; supervisor cierra con motivo → queda
        registrado motivo/usuario/fecha; se genera ajuste de
        inventario."""
        dayroute = self._crear_dayroute(905)
        self._control_playa(dayroute, "salida", [{"product_id": self.bidon15.id, "cantidad": 42}])

        cliente = self._crear_cliente("Cliente CT07")
        self.env["insa.movimiento.cliente"].create(
            {
                "hoja_ruta_id": dayroute.id,
                "partner_id": cliente.id,
                "linea_articulo_ids": [
                    (0, 0, {"product_id": self.bidon15.id, "cantidad": 27, "precio_unitario": 100})
                ],
            }
        )
        self._control_playa(dayroute, "entrada", [{"product_id": self.bidon15.id, "cantidad": 9}])

        dayroute.action_registrar_caja()
        self.assertEqual(dayroute.state, "consolidando")
        self.assertTrue(dayroute.tiene_diferencias)

        # bloqueado para usuario común
        with self.assertRaises(UserError):
            dayroute.action_cerrar_hoja_ruta()

        # bloqueado para forzar sin ser supervisor — se saca el grupo
        # explícitamente en vez de asumir que el usuario no lo tiene: si
        # hay datos de demo u otro test que ya se lo dieron al admin (no
        # hace rollback como sí hacen los tests entre sí), la aserción de
        # abajo daría un falso negativo sin este paso.
        supervisor_group = self.env.ref("insa_reparto.group_supervisor")
        self.env.user.write({"groups_id": [(3, supervisor_group.id)]})
        self.assertFalse(self.env.user.has_group("insa_reparto.group_supervisor"))
        with self.assertRaises(UserError):
            dayroute.action_cerrar_con_diferencias("motivo cualquiera")

        # se habilita el supervisor
        self.env.user.write({"groups_id": [(4, supervisor_group.id)]})

        motivo = "Se acepta la diferencia, revisado por cámaras."
        dayroute.action_cerrar_con_diferencias(motivo)

        self.assertEqual(dayroute.state, "cerrada")
        self.assertTrue(dayroute.close_forced)
        self.assertEqual(dayroute.close_forced_reason, motivo)
        self.assertEqual(dayroute.close_forced_by, self.env.user)
        self.assertTrue(dayroute.close_forced_date)

        ajuste_articulo = dayroute.ajuste_inventario_ids.filtered(lambda a: a.tipo == "articulo")
        self.assertTrue(ajuste_articulo)
        self.assertEqual(ajuste_articulo.diferencia, 6)
        self.assertEqual(ajuste_articulo.motivo, motivo)

        # la hoja de ruta queda readonly (§5.7)
        with self.assertRaises(UserError):
            dayroute.write({"efectivo_caja_repartidor": 999})
