# Copyright 2026 Olpa Group
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)
from odoo import _, api, fields, models
from odoo.exceptions import UserError


class InsaMovimientoCliente(models.Model):
    _name = "insa.movimiento.cliente"
    _description = "Movimiento por cliente (evento de visita)"
    _order = "secuencia"

    hoja_ruta_id = fields.Many2one(
        comodel_name="fsm.route.dayroute",
        string="Hoja de ruta",
        required=True,
        ondelete="cascade",
    )
    partner_id = fields.Many2one(
        comodel_name="res.partner", string="Cliente", required=True
    )
    secuencia = fields.Integer(string="Secuencia de visita", default=10)
    fecha_hora = fields.Datetime(default=fields.Datetime.now)

    # RN-19: íconos por visita acumulables — visitado/resultado son
    # independientes entre sí (se puede estar "visitado" y a la vez
    # "ausente"), y tiene_venta/tiene_mov_envase/tiene_cobro se derivan
    # solos de lo que efectivamente se cargó.
    visitado = fields.Boolean(
        string="Visitado",
        default=True,
        help="Hubo una visita física al domicilio. Desmarcar para el caso "
        "de 'sin gestión' resuelto por WhatsApp sin ir (RN-18).",
    )
    resultado = fields.Selection(
        selection=[
            ("ausente", "Ausente"),
            ("sin_gestion", "Sin gestión"),
        ],
        string="Resultado sin transacción",
        help="Dejar vacío si hubo venta, cobro o movimiento de envase. "
        "Completar solo para una visita sin transacción.",
    )
    cobro_efectivo = fields.Float(string="Cobro en efectivo")
    linea_articulo_ids = fields.One2many(
        comodel_name="insa.movimiento.cliente.linea.articulo",
        inverse_name="movimiento_id",
        string="Líneas de artículos",
    )
    linea_envase_ids = fields.One2many(
        comodel_name="insa.movimiento.cliente.linea.envase",
        inverse_name="movimiento_id",
        string="Líneas de envases",
    )
    envase_movido = fields.Boolean(default=False, readonly=True, copy=False)

    tiene_venta = fields.Boolean(compute="_compute_iconos", store=True)
    tiene_devolucion_articulo = fields.Boolean(compute="_compute_iconos", store=True)
    tiene_mov_envase = fields.Boolean(compute="_compute_iconos", store=True)
    tiene_cobro = fields.Boolean(compute="_compute_iconos", store=True)

    @api.depends("linea_articulo_ids.tipo", "linea_envase_ids", "cobro_efectivo")
    def _compute_iconos(self):
        for rec in self:
            rec.tiene_venta = bool(
                rec.linea_articulo_ids.filtered(lambda l: l.tipo == "venta")
            )
            rec.tiene_devolucion_articulo = bool(
                rec.linea_articulo_ids.filtered(lambda l: l.tipo == "devolucion")
            )
            rec.tiene_mov_envase = bool(rec.linea_envase_ids)
            rec.tiene_cobro = bool(rec.cobro_efectivo)

    iconos_visita = fields.Char(
        string="Íconos",
        compute="_compute_iconos_visita",
        store=True,
        help="RN-19: representación textual de los íconos acumulables del "
        "sistema actual de INSA (✔️ visitado · 🛒 venta · ↩️ devolución de "
        "artículo · ➡️ movimiento de envase · ☕ ausente · ❗ sin gestión · "
        "💲 cobró). Se usan los emoji reales en vez de un widget de íconos "
        "a medida, para no depender de JS custom en este spike. Paso 1.8 "
        "(sin confirmar con el cliente): ícono de devolución de artículo "
        "agregado por interpretación propia de los apuntes de la reunión, "
        "ver 'Preguntas para el cliente' del plan de trabajo.",
    )

    @api.depends(
        "visitado",
        "resultado",
        "tiene_venta",
        "tiene_devolucion_articulo",
        "tiene_mov_envase",
        "tiene_cobro",
    )
    def _compute_iconos_visita(self):
        for rec in self:
            partes = []
            if rec.visitado:
                partes.append("✔️")
            if rec.tiene_venta:
                partes.append("🛒")
            if rec.tiene_devolucion_articulo:
                partes.append("↩️")
            if rec.tiene_mov_envase:
                partes.append("➡️")
            if rec.resultado == "ausente":
                partes.append("☕")
            if rec.resultado == "sin_gestion":
                partes.append("❗")
            if rec.tiene_cobro:
                partes.append("💲")
            rec.iconos_visita = " ".join(partes)

    @api.constrains("hoja_ruta_id")
    def _check_hoja_ruta_iniciada(self):
        # RN-01: no puede haber visitas antes del control de playa de salida.
        for rec in self:
            if rec.hoja_ruta_id.state == "borrador":
                raise UserError(
                    _(
                        "No se pueden registrar visitas: la hoja de ruta %s "
                        "todavía está en Borrador (falta el control de playa "
                        "de salida)."
                    )
                    % rec.hoja_ruta_id.name
                )

    def action_confirmar(self):
        """Genera los stock.move de envase por cada línea de envase, del
        camión (ubicación de stock del almacén de la ruta) al cliente
        (property_stock_customer) o viceversa según prestamo/devolución.

        Simplificación de este spike: se usa la ubicación de stock del
        almacén por defecto como "camión", porque fsm.route no tiene
        almacén propio — a revisar con Lucas si hace falta una
        ubicación por vehículo/ruta en vez de una genérica de almacén.
        """
        for rec in self:
            if rec.envase_movido:
                continue
            camion = self.env["stock.warehouse"].search([], limit=1).lot_stock_id
            cliente_loc = rec.partner_id.property_stock_customer
            if not cliente_loc:
                raise UserError(
                    _("El cliente %s no tiene ubicación de stock asignada.")
                    % rec.partner_id.name
                )
            for linea in rec.linea_envase_ids:
                envase = linea.product_id.envase_id
                if not envase:
                    raise UserError(
                        _("El producto %s no tiene un envase vinculado.")
                        % linea.product_id.name
                    )
                origen, destino = (
                    (camion, cliente_loc)
                    if linea.tipo == "prestamo"
                    else (cliente_loc, camion)
                )
                move = self.env["stock.move"].create(
                    {
                        "name": f"{rec.partner_id.name} - {envase.name}",
                        "product_id": envase.product_variant_id.id,
                        "product_uom_qty": linea.cantidad,
                        "product_uom": envase.uom_id.id,
                        "location_id": origen.id,
                        "location_dest_id": destino.id,
                    }
                )
                move._action_confirm()
                move._action_assign()
                move.quantity = linea.cantidad
                move.picked = True
                move._action_done()
            rec.envase_movido = True
        return True


class InsaMovimientoClienteLineaArticulo(models.Model):
    _name = "insa.movimiento.cliente.linea.articulo"
    _description = "Línea de venta o devolución de artículos"

    movimiento_id = fields.Many2one(
        comodel_name="insa.movimiento.cliente", required=True, ondelete="cascade"
    )
    product_id = fields.Many2one(
        comodel_name="product.template", string="Producto", required=True
    )
    tipo = fields.Selection(
        selection=[("venta", "Venta"), ("devolucion", "Devolución")],
        required=True,
        default="venta",
        help="Paso 1.8 (sin confirmar con el cliente): distingue una venta "
        "de una devolución de artículo para el cotejo automático contra "
        "el control de playa de entrada (RN a definir con el cliente, ver "
        "'Preguntas para el cliente' del plan de trabajo). Una devolución "
        "resta del neto entregado en vez de sumar.",
    )
    cantidad = fields.Float(string="Cantidad", default=1.0)
    precio_unitario = fields.Float(string="Precio unitario")
    subtotal = fields.Float(string="Subtotal", compute="_compute_subtotal", store=True)

    @api.depends("cantidad", "precio_unitario")
    def _compute_subtotal(self):
        for rec in self:
            rec.subtotal = rec.cantidad * rec.precio_unitario


class InsaMovimientoClienteLineaEnvase(models.Model):
    _name = "insa.movimiento.cliente.linea.envase"
    _description = "Línea de envases (préstamo/devolución)"

    movimiento_id = fields.Many2one(
        comodel_name="insa.movimiento.cliente", required=True, ondelete="cascade"
    )
    product_id = fields.Many2one(
        comodel_name="product.template",
        string="Producto retornable",
        required=True,
        domain=[("es_retornable", "=", True)],
    )
    tipo = fields.Selection(
        selection=[("prestamo", "Préstamo"), ("devolucion", "Devolución")],
        required=True,
    )
    cantidad = fields.Float(string="Cantidad", default=1.0)
    sin_alerta_previa = fields.Boolean(
        string="Sin alerta previa",
        readonly=True,
        copy=False,
        help="Paso 1.10: se completa solo al crear la línea. True si, en "
        "ese momento, el cliente no tenía deuda de este envase (RN 3.4 "
        "del doc D1: la app le muestra al repartidor la deuda ANTES de "
        "la visita, para que la reclame) — distingue una devolución "
        "esperada de una que el sistema no había anticipado. Solo tiene "
        "sentido para tipo='devolucion'; en préstamo queda siempre False.",
    )

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        Saldo = self.env["insa.saldo.envase"].sudo()
        for rec in records:
            if rec.tipo != "devolucion":
                continue
            saldo = Saldo.search(
                [
                    ("partner_id", "=", rec.movimiento_id.partner_id.id),
                    ("product_id", "=", rec.product_id.id),
                ],
                limit=1,
            )
            rec.sin_alerta_previa = not saldo or saldo.cantidad_a_recuperar <= 0
        return records
