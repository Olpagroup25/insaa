# Copyright 2026 Olpa Group
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)
from odoo import _, api, fields, models
from odoo.exceptions import UserError


class FSMRouteDayroute(models.Model):
    """Esta es la "hoja de ruta" (insa.hoja.ruta) de la tarjeta técnica,
    implementada como extensión de fsm.route.dayroute (OCA
    fieldservice_route) — NO como modelo nuevo. La tarjeta original decía
    fsm.route.day por error; fsm.route.day es solo el selector de día de
    semana (Monday..Sunday), fsm.route.dayroute es la hoja de ruta
    concreta de un repartidor en una fecha. Ver spike del 24/07/2026."""

    _name = "fsm.route.dayroute"
    _inherit = ["fsm.route.dayroute", "mail.thread"]

    reparto_numero = fields.Integer(
        string="N° de reparto / móvil",
        related="route_id.numero_reparto",
        store=True,
        readonly=True,
        tracking=True,
        help="Se hereda de la ruta (fsm.route.numero_reparto); ya no se "
        "tipea a mano en cada hoja de ruta para evitar que quede "
        "inconsistente día a día.",
    )
    dia_semana = fields.Selection(
        selection=[
            ("0", "Lunes"),
            ("1", "Martes"),
            ("2", "Miércoles"),
            ("3", "Jueves"),
            ("4", "Viernes"),
            ("5", "Sábado"),
            ("6", "Domingo"),
        ],
        string="Día de la semana",
        compute="_compute_dia_semana",
        store=True,
        help="Derivado de `date` (date.weekday(), Lunes=0). Dato oficial "
        "para reportes/liquidación — la app puede seguir mostrando su "
        "propio cálculo en DateSelectionScreen, pero este es el que "
        "queda persistido en el backend.",
    )
    vehiculo_id = fields.Many2one(comodel_name="fleet.vehicle", string="Vehículo")
    repartidor_id = fields.Many2one(
        comodel_name="hr.employee",
        string="Repartidor",
        tracking=True,
        help="Empleado asignado a este reparto. Complementa a person_id "
        "(fsm.person, nativo de OCA) para vincular con la ficha de "
        "legajo/nómina del repartidor.",
    )

    state = fields.Selection(
        selection=[
            ("borrador", "Borrador"),
            ("en_reparto", "En reparto"),
            ("consolidando", "Consolidando"),
            ("cerrada", "Cerrada"),
        ],
        default="borrador",
        required=True,
        tracking=True,
        copy=False,
    )
    efectivo_caja_repartidor = fields.Float(
        string="Efectivo declarado en caja",
        help="Simplificación de este spike: monto ingresado manualmente al "
        "confirmar el cierre de caja del repartidor. Falta definir con "
        "Lucas si se integra con account.bank.statement (diario de caja) "
        "o se mantiene así de simple para la primera entrega.",
    )

    control_playa_ids = fields.One2many(
        comodel_name="insa.control.playa",
        inverse_name="hoja_ruta_id",
        string="Controles de playa",
    )
    movimiento_cliente_ids = fields.One2many(
        comodel_name="insa.movimiento.cliente",
        inverse_name="hoja_ruta_id",
        string="Movimientos por cliente",
    )
    pedido_extra_ids = fields.One2many(
        comodel_name="insa.pedido.extra",
        inverse_name="hoja_ruta_id",
        string="Pedidos extra",
    )
    liquidacion_articulo_ids = fields.One2many(
        comodel_name="insa.liquidacion.articulo",
        inverse_name="hoja_ruta_id",
        string="Liquidación de artículos",
    )
    liquidacion_envase_ids = fields.One2many(
        comodel_name="insa.liquidacion.envase",
        inverse_name="hoja_ruta_id",
        string="Liquidación de envases",
    )
    ajuste_inventario_ids = fields.One2many(
        comodel_name="insa.ajuste.inventario",
        inverse_name="hoja_ruta_id",
        string="Ajustes de inventario por cierre forzado",
    )
    total_efectivo_registrado = fields.Float(
        string="Efectivo registrado",
        compute="_compute_efectivo",
        store=True,
    )
    diferencia_efectivo = fields.Float(
        string="Diferencia de efectivo",
        compute="_compute_efectivo",
        store=True,
    )
    tiene_diferencias = fields.Boolean(
        string="Tiene diferencias",
        compute="_compute_tiene_diferencias",
        store=True,
    )

    close_forced = fields.Boolean(string="Cerrada con diferencias", readonly=True, copy=False)
    close_forced_reason = fields.Text(string="Motivo del cierre forzado", readonly=True, copy=False)
    close_forced_by = fields.Many2one(
        comodel_name="res.users", string="Cerrada por", readonly=True, copy=False
    )
    close_forced_date = fields.Datetime(string="Fecha de cierre forzado", readonly=True, copy=False)

    def write(self, vals):
        # §5.7: "Cerrada" es readonly total, sin edición posterior. Se lee
        # rec.state ANTES de aplicar vals, así que el propio write que
        # pasa a 'cerrada' (hecho desde 'consolidando') no se autobloquea.
        # Nota: esto solo protege la cabecera; los modelos hijos (control
        # de playa, movimientos por cliente, pedidos extra) todavía no
        # heredan este bloqueo — queda como gap documentado, no se
        # generalizó por no ser parte explícita de RN-12/13/14 ni de CT-07.
        for rec in self:
            if rec.state == "cerrada":
                raise UserError(
                    _("La hoja de ruta %s está cerrada, no se puede modificar.")
                    % rec.name
                )
        return super().write(vals)

    def unlink(self):
        for rec in self:
            if rec.state == "cerrada":
                raise UserError(
                    _("La hoja de ruta %s está cerrada, no se puede eliminar.")
                    % rec.name
                )
        return super().unlink()

    @api.depends("date")
    def _compute_dia_semana(self):
        for rec in self:
            rec.dia_semana = str(rec.date.weekday()) if rec.date else False

    @api.depends("movimiento_cliente_ids.cobro_efectivo", "efectivo_caja_repartidor")
    def _compute_efectivo(self):
        for rec in self:
            rec.total_efectivo_registrado = sum(
                rec.movimiento_cliente_ids.mapped("cobro_efectivo")
            )
            rec.diferencia_efectivo = (
                rec.total_efectivo_registrado - rec.efectivo_caja_repartidor
            )

    @api.depends(
        "liquidacion_articulo_ids.diferencia",
        "liquidacion_envase_ids.diferencia",
        "diferencia_efectivo",
    )
    def _compute_tiene_diferencias(self):
        for rec in self:
            rec.tiene_diferencias = (
                any(rec.liquidacion_articulo_ids.mapped(lambda l: l.diferencia != 0))
                or any(rec.liquidacion_envase_ids.mapped(lambda l: l.diferencia != 0))
                or rec.diferencia_efectivo != 0
            )

    def action_recalcular_liquidacion(self):
        for rec in self:
            rec.liquidacion_articulo_ids.unlink()
            rec.liquidacion_envase_ids.unlink()
            rec._crear_liquidacion_articulos()
            rec._crear_liquidacion_envases()
        return True

    def _crear_liquidacion_articulos(self):
        salidas, entradas, registrado = {}, {}, {}
        for playa in self.control_playa_ids:
            destino = salidas if playa.tipo == "salida" else entradas
            for linea in playa.linea_ids:
                destino[linea.product_id] = destino.get(linea.product_id, 0.0) + linea.cantidad
        for mov in self.movimiento_cliente_ids:
            for linea in mov.linea_articulo_ids:
                # Paso 1.8 (sin confirmar con el cliente): una devolución
                # de artículo resta del neto entregado, en vez de sumar
                # como una venta — así el cotejo contra el control de
                # playa de entrada (teorico = salidas - entradas físicas)
                # se resuelve solo con el mismo cálculo de diferencia que
                # ya existe, sin un gate nuevo. Ver "Preguntas para el
                # cliente" del plan de trabajo.
                signo = -1 if linea.tipo == "devolucion" else 1
                registrado[linea.product_id] = registrado.get(
                    linea.product_id, 0.0
                ) + signo * linea.cantidad
        productos = set(salidas) | set(entradas) | set(registrado)
        for producto in productos:
            teorico = salidas.get(producto, 0.0) - entradas.get(producto, 0.0)
            reg = registrado.get(producto, 0.0)
            self.env["insa.liquidacion.articulo"].create(
                {
                    "hoja_ruta_id": self.id,
                    "product_id": producto.id,
                    "teorico": teorico,
                    "registrado": reg,
                }
            )

    def _crear_liquidacion_envases(self):
        salidas, prestamos, devoluciones, entrada_real = {}, {}, {}, {}
        for playa in self.control_playa_ids:
            for linea in playa.linea_ids:
                if not linea.product_id.es_retornable:
                    continue
                if playa.tipo == "salida":
                    salidas[linea.product_id] = (
                        salidas.get(linea.product_id, 0.0) + linea.cantidad
                    )
                else:
                    entrada_real[linea.product_id] = entrada_real.get(
                        linea.product_id, 0.0
                    ) + (linea.cantidad + linea.cantidad_vacia)
        for mov in self.movimiento_cliente_ids:
            for linea in mov.linea_envase_ids:
                destino = prestamos if linea.tipo == "prestamo" else devoluciones
                destino[linea.product_id] = (
                    destino.get(linea.product_id, 0.0) + linea.cantidad
                )
        productos = set(salidas) | set(prestamos) | set(devoluciones) | set(entrada_real)
        for producto in productos:
            entrada_teorica = (
                salidas.get(producto, 0.0)
                - prestamos.get(producto, 0.0)
                + devoluciones.get(producto, 0.0)
            )
            real = entrada_real.get(producto, 0.0)
            self.env["insa.liquidacion.envase"].create(
                {
                    "hoja_ruta_id": self.id,
                    "product_id": producto.id,
                    "entrada_teorica": entrada_teorica,
                    "entrada_real": real,
                }
            )

    def action_registrar_caja(self):
        for rec in self:
            if rec.state != "en_reparto":
                raise UserError(_("Solo se puede registrar caja desde 'En reparto'."))
            if not rec.control_playa_ids.filtered(lambda c: c.tipo == "entrada"):
                raise UserError(
                    _(
                        "Falta el control de playa de ENTRADA: no se puede "
                        "pasar a Consolidando sin el conteo de llenos y "
                        "vacíos del regreso del camión."
                    )
                )
            rec.action_recalcular_liquidacion()
            rec.state = "consolidando"
        return True

    def action_cerrar_hoja_ruta(self):
        for rec in self:
            if rec.state != "consolidando":
                raise UserError(_("Solo se puede cerrar desde 'Consolidando'."))
            if rec.tiene_diferencias:
                raise UserError(
                    _(
                        "Hay diferencias sin resolver. Un supervisor puede "
                        "forzar el cierre con motivo desde 'Cerrar con diferencias'."
                    )
                )
            rec.state = "cerrada"
        return True

    def action_abrir_wizard_cerrar_con_diferencias(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Cerrar con diferencias"),
            "res_model": "insa.cerrar.con.diferencias.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_hoja_ruta_id": self.id},
        }

    def action_cerrar_con_diferencias(self, motivo):
        if not self.env.user.has_group("insa_reparto.group_supervisor"):
            raise UserError(_("Solo un supervisor puede forzar el cierre con diferencias."))
        if not motivo:
            raise UserError(_("El motivo es obligatorio para forzar el cierre."))
        for rec in self:
            if rec.state != "consolidando":
                raise UserError(_("Solo se puede cerrar desde 'Consolidando'."))
            rec.write(
                {
                    "state": "cerrada",
                    "close_forced": True,
                    "close_forced_reason": motivo,
                    "close_forced_by": self.env.user.id,
                    "close_forced_date": fields.Datetime.now(),
                }
            )
            rec.message_post(
                body=_("Hoja de ruta cerrada con diferencias. Motivo: %s") % motivo
            )
            rec._generar_ajustes_inventario(motivo)
        return True

    def _generar_ajustes_inventario(self, motivo):
        """R-6.4: toda diferencia no resuelta queda auditada en
        insa.ajuste.inventario (quién, cuándo, motivo, cuánto).

        Solo para ENVASES se corrige además la cantidad física real en
        stock (con el mecanismo estándar de ajuste de inventario de
        Odoo, stock.quant.inventory_quantity) — el envase es el único
        producto que este módulo obliga a trackear en stock (ver
        product.template._check_envase_es_storable). Para ARTÍCULOS no
        se genera movimiento: el conteo de playa (salida/entrada) ya ES
        la cantidad física real; lo que falta ahí es el registro de la
        venta, no una corrección de inventario, así que queda solo
        como auditoría.

        El asiento contable contra una cuenta de mermas/faltantes
        [PARA INSA] no se implementa acá — decisión del checkpoint del
        06/08/2026, queda pendiente."""
        Ajuste = self.env["insa.ajuste.inventario"]
        for rec in self:
            for linea in rec.liquidacion_articulo_ids.filtered("diferencia"):
                Ajuste.create(
                    {
                        "hoja_ruta_id": rec.id,
                        "tipo": "articulo",
                        "product_id": linea.product_id.id,
                        "diferencia": linea.diferencia,
                        "motivo": motivo,
                    }
                )
            for linea in rec.liquidacion_envase_ids.filtered("diferencia"):
                move = linea._ajustar_stock_envase()
                Ajuste.create(
                    {
                        "hoja_ruta_id": rec.id,
                        "tipo": "envase",
                        "product_id": linea.product_id.id,
                        "diferencia": linea.diferencia,
                        "motivo": motivo,
                        "stock_move_id": move.id if move else False,
                    }
                )


class InsaCerrarConDiferenciasWizard(models.TransientModel):
    _name = "insa.cerrar.con.diferencias.wizard"
    _description = "Cerrar hoja de ruta con diferencias (motivo obligatorio)"

    hoja_ruta_id = fields.Many2one(comodel_name="fsm.route.dayroute", required=True)
    motivo = fields.Text(required=True)

    def action_confirmar(self):
        self.ensure_one()
        self.hoja_ruta_id.action_cerrar_con_diferencias(self.motivo)


class InsaLiquidacionArticulo(models.Model):
    _name = "insa.liquidacion.articulo"
    _description = "Línea de liquidación de artículos"

    hoja_ruta_id = fields.Many2one(
        comodel_name="fsm.route.dayroute", required=True, ondelete="cascade"
    )
    product_id = fields.Many2one(comodel_name="product.template", string="Producto")
    teorico = fields.Float(string="Teórico entregado")
    registrado = fields.Float(string="Registrado")
    diferencia = fields.Float(string="Diferencia", compute="_compute_diferencia", store=True)

    @api.depends("teorico", "registrado")
    def _compute_diferencia(self):
        # RN-06: diferencia = teórico entregado − registrado (no al revés).
        for rec in self:
            rec.diferencia = rec.teorico - rec.registrado


class InsaLiquidacionEnvase(models.Model):
    _name = "insa.liquidacion.envase"
    _description = "Línea de liquidación de envases"

    hoja_ruta_id = fields.Many2one(
        comodel_name="fsm.route.dayroute", required=True, ondelete="cascade"
    )
    product_id = fields.Many2one(comodel_name="product.template", string="Producto retornable")
    entrada_teorica = fields.Float(string="Entrada teórica")
    entrada_real = fields.Float(string="Entrada real")
    diferencia = fields.Float(string="Diferencia", compute="_compute_diferencia", store=True)

    @api.depends("entrada_teorica", "entrada_real")
    def _compute_diferencia(self):
        # RN-07/RN-08: diferencia = entrada teórica − entrada real.
        for rec in self:
            rec.diferencia = rec.entrada_teorica - rec.entrada_real

    def _ajustar_stock_envase(self):
        """R-6.4: corrige la cantidad física del envase en la ubicación
        del camión para que quede acorde al conteo real verificado en
        el control de playa. Usa el mecanismo estándar de ajuste de
        inventario de Odoo (stock.quant.inventory_quantity) — sin
        tocar contabilidad. Devuelve el stock.move generado, o False
        si no hay envase trackeable o no hay diferencia."""
        self.ensure_one()
        if not self.diferencia:
            return False
        envase = self.product_id.envase_id
        if not envase or not envase.is_storable:
            return False
        variante = envase.product_variant_id
        camion = self.env["stock.warehouse"].search([], limit=1).lot_stock_id
        quant = self.env["stock.quant"]._gather(variante, camion, strict=True)[:1]
        if not quant:
            quant = self.env["stock.quant"].create(
                {"product_id": variante.id, "location_id": camion.id}
            )
        # diferencia = entrada_teórica − entrada_real (RN-07/08): si es
        # positiva falta stock físico, si es negativa sobra.
        quant = quant.with_context(inventory_mode=True)
        quant.inventory_quantity = quant.quantity - self.diferencia
        quant.action_apply_inventory()
        # action_apply_inventory() no devuelve ni linkea el stock.move que
        # genera; lo recuperamos por búsqueda (solo para dejarlo linkeado
        # en la auditoría, no afecta el ajuste en sí, que ya se aplicó).
        return self.env["stock.move"].search(
            [
                ("product_id", "=", variante.id),
                ("state", "=", "done"),
                "|",
                ("location_id", "=", camion.id),
                ("location_dest_id", "=", camion.id),
            ],
            order="id desc",
            limit=1,
        )
