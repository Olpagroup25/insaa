# Copyright 2026 Olpa Group
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)
from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError


class InsaControlPlaya(models.Model):
    _name = "insa.control.playa"
    _description = "Control de playa (salida/entrada)"

    hoja_ruta_id = fields.Many2one(
        comodel_name="fsm.route.dayroute",
        string="Hoja de ruta",
        required=True,
        ondelete="cascade",
    )
    tipo = fields.Selection(
        selection=[("salida", "Salida"), ("entrada", "Entrada")],
        required=True,
    )
    fecha_hora = fields.Datetime(default=fields.Datetime.now, required=True)
    user_id = fields.Many2one(
        comodel_name="res.users", string="Usuario", default=lambda self: self.env.user
    )
    kilometros = fields.Float(
        string="Kilómetros",
        help="Lectura del odómetro al momento del control. No surge del "
        "documento D1 ni de la reunión — viene del diseño de "
        "ControlDePlayaDialog (D3); se agrega igual por ser de bajo "
        "riesgo, a diferencia de Dispensers/Repuestos que sí están "
        "explícitamente fuera de alcance de D1.",
    )
    linea_ids = fields.One2many(
        comodel_name="insa.control.playa.linea",
        inverse_name="control_playa_id",
        string="Líneas",
    )
    aprobado_por_id = fields.Many2one(
        comodel_name="res.users",
        string="Aprobado por (controlador)",
        readonly=True,
        copy=False,
        help="Supuesto 0.1: segundo factor de aprobación, usuario/contraseña "
        "real de Odoo con el grupo insa_reparto.group_controlador. Se "
        "completa vía POST /insa/api/control-playa/aprobar, nunca a mano.",
    )
    aprobado_fecha = fields.Datetime(string="Fecha de aprobación", readonly=True, copy=False)

    _sql_constraints = [
        (
            "hoja_ruta_tipo_unique",
            "unique(hoja_ruta_id, tipo)",
            "Ya existe un control de playa de este tipo para esta hoja de ruta "
            "(RN-04: la liquidación asume un único control de salida y uno de "
            "entrada por reparto).",
        ),
    ]

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        records._maybe_iniciar_reparto()
        return records

    def write(self, vals):
        res = super().write(vals)
        if "linea_ids" in vals or "tipo" in vals:
            self._maybe_iniciar_reparto()
        return res

    def _maybe_iniciar_reparto(self):
        """RN-01: registrar el control de playa de SALIDA (con al menos
        una línea cargada) es lo que saca la hoja de ruta de 'borrador' y
        la pasa a 'en_reparto'. Se chequea en create() y en write() porque
        desde el formulario la cabecera puede guardarse antes que las
        líneas (list editable inline genera un write() por separado)."""
        for rec in self:
            if (
                rec.tipo == "salida"
                and rec.linea_ids
                and rec.hoja_ruta_id.state == "borrador"
            ):
                rec.hoja_ruta_id.state = "en_reparto"


class InsaControlPlayaLinea(models.Model):
    _name = "insa.control.playa.linea"
    _description = "Línea de control de playa"

    control_playa_id = fields.Many2one(
        comodel_name="insa.control.playa", required=True, ondelete="cascade"
    )
    tipo = fields.Selection(related="control_playa_id.tipo")
    product_id = fields.Many2one(
        comodel_name="product.template",
        string="Producto",
        required=True,
        domain=[("visible_control_playa", "=", True)],
    )
    cantidad = fields.Float(
        string="Cantidad",
        help="En salida: cantidad total (se asume todo lleno). "
        "En entrada: cantidad llena.",
    )
    cantidad_vacia = fields.Float(
        string="Cantidad vacía",
        help="Solo aplica en control de entrada.",
    )

    @api.constrains("cantidad_vacia")
    def _check_salida_sin_vacios(self):
        # RN-02: el control de salida asume todo lleno, no distingue vacíos.
        # 'tipo' es un related no-stored (viene de control_playa_id.tipo):
        # no puede ir en @api.constrains (Odoo tira warning, "not
        # writeable"), pero sí se puede leer adentro sin problema.
        for rec in self:
            if rec.tipo == "salida" and rec.cantidad_vacia:
                raise ValidationError(
                    _(
                        "%s: un control de playa de SALIDA no registra "
                        "cantidad vacía (se asume que todo sale lleno)."
                    )
                    % rec.product_id.name
                )

    @api.constrains("cantidad", "cantidad_vacia")
    def _check_cantidades_no_negativas(self):
        for rec in self:
            if rec.cantidad < 0 or rec.cantidad_vacia < 0:
                raise ValidationError(
                    _("%s: las cantidades de un control de playa no pueden ser negativas.")
                    % rec.product_id.name
                )
