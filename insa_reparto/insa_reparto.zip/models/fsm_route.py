# Copyright 2026 Olpa Group
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)
from odoo import fields, models


class FSMRoute(models.Model):
    """La ruta/móvil persistente ("Reparto 01"..."Reparto 17"). Vive acá
    y no en fsm.route.dayroute porque el número identifica al móvil/ruta,
    no al día concreto — lo confirma la reunión ("distribuidor número 9")
    y es la base del login de la app de reparto (D3), ver
    insa.repartidor.credencial."""

    _inherit = "fsm.route"

    numero_reparto = fields.Integer(
        string="N° de reparto",
        help="El \"Reparto 1\", \"Reparto 2\" que usa INSA a diario "
        "(~17 rutas). Determina el login de la app: "
        "\"reparto01@insareparto.local\".",
    )

    _sql_constraints = [
        (
            "numero_reparto_unique",
            "unique(numero_reparto)",
            "Ya existe una ruta con ese número de reparto.",
        ),
    ]
