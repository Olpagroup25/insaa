# Copyright 2026 Olpa Group
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)
from datetime import timedelta

from odoo import _, api, fields, models

FUE_DIAS = 30


class ResPartner(models.Model):
    _inherit = "res.partner"

    alias_bancario = fields.Char(
        string="Alias bancario",
        help="Formato INSA.<nro_cliente>. Insumo para la conciliación "
        "bancaria automática (Fase 2), no se usa todavía en D1.",
    )
    insa_saldo_envase_ids = fields.One2many(
        comodel_name="insa.saldo.envase",
        inverse_name="partner_id",
        string="Saldo de envases",
    )
    insa_ubicacion_stock_creada = fields.Boolean(
        default=False,
        copy=False,
        help="Marca interna: evita crear dos veces la ubicación de stock "
        "dedicada del cliente. No usar 'if property_stock_customer' para "
        "esto — es un campo company_dependent y siempre devuelve un valor "
        "truthy (el default genérico) aunque no se haya seteado nada.",
    )
    insa_picking_ids = fields.One2many(
        comodel_name="stock.picking", inverse_name="partner_id", string="Entregas (INSA)"
    )
    insa_payment_ids = fields.One2many(
        comodel_name="account.payment", inverse_name="partner_id", string="Cobros (INSA)"
    )

    # -- Formulario de alta público (feature-formulario-alta) ---------------
    # Domicilio estructurado (formato argentino) + datos de facturación,
    # capturados por /formulario-alta-insa (controllers/
    # insa_registration_controller.py). No toca customer_rank a propósito:
    # un alta acá es un lead/contacto nuevo, no un cliente de reparto
    # confirmado — no aparece en el Buscador (Paso 2.6) ni puede recibir
    # visitas hasta que INSA lo convierta en cliente por el circuito
    # normal de Odoo.
    insa_city_id = fields.Many2one(comodel_name="insa.city", string="Ciudad o Barrio")
    insa_street_id = fields.Many2one(comodel_name="insa.street", string="Calle")
    insa_street_number = fields.Char(string="Número")
    insa_floor = fields.Char(string="Piso")
    insa_apartment = fields.Char(string="Departamento")
    insa_tower = fields.Char(string="Torre")
    insa_block = fields.Char(string="Manzana")
    insa_lot = fields.Char(string="Lote")
    insa_address_notes = fields.Text(string="Referencias del domicilio")
    insa_tax_condition = fields.Selection(
        selection=[
            ("consumidor_final", "Consumidor Final"),
            ("responsable_inscripto", "Responsable Inscripto"),
            ("monotributista", "Monotributista"),
            ("exento", "Exento"),
        ],
        string="Condición fiscal",
        default="consumidor_final",
    )
    insa_order_notes = fields.Text(string="Pedidos u observaciones")

    fecha_ultima_entrega = fields.Date(
        string="Fecha última entrega (FUE)",
        compute="_compute_fue_fuc",
        store=True,
        help="Paso 1.12: campo dedicado (antes se calculaba on-the-fly en "
        "cada request de GET /insa/api/hoja-de-ruta). Umbral fijo de 30 "
        "días confirmado por el cliente (supuesto 0.5) — ver "
        "_cron_check_fue.",
    )
    fecha_ultima_cobranza = fields.Date(
        string="Fecha último cobro",
        compute="_compute_fue_fuc",
        store=True,
    )

    @api.depends(
        "insa_picking_ids.date_done",
        "insa_picking_ids.state",
        "insa_picking_ids.picking_type_id.code",
        "insa_payment_ids.date",
        "insa_payment_ids.state",
        "insa_payment_ids.payment_type",
    )
    def _compute_fue_fuc(self):
        for partner in self:
            entregas = partner.insa_picking_ids.filtered(
                lambda p: p.picking_type_id.code == "outgoing"
                and p.state == "done"
                and p.date_done
            )
            partner.fecha_ultima_entrega = (
                max(entregas.mapped("date_done")).date() if entregas else False
            )
            cobros = partner.insa_payment_ids.filtered(
                lambda p: p.payment_type == "inbound" and p.state == "paid"
            )
            partner.fecha_ultima_cobranza = max(cobros.mapped("date")) if cobros else False

    def _cron_check_fue(self):
        """Paso 1.12 (supuesto 0.5, ya confirmado por el cliente): FUE fijo
        en 30 días + notificación al superarse. El canal real (push/email/
        WhatsApp) sigue sin confirmar (ver 'Preguntas para el cliente' del
        plan de trabajo), así que el disparo es una actividad de Odoo
        (mail.activity) asignada a un supervisor — conectar el canal
        definitivo ahí el día que se confirme, sin tocar esta detección."""
        limite = fields.Date.context_today(self) - timedelta(days=FUE_DIAS)
        vencidos = self.search(
            [
                # Bug encontrado en el Paso 2.6: type == "fsm_location" no
                # matchea nunca un cliente real (verificado contra datos
                # reales — "fsm_location" es el tipo que OCA fieldservice
                # usa para el partner de la *ubicación*, no del cliente,
                # que en la práctica es type='contact'). customer_rank > 0
                # es el criterio estándar de Odoo para "es un cliente".
                ("customer_rank", ">", 0),
                ("fecha_ultima_entrega", "!=", False),
                ("fecha_ultima_entrega", "<", limite),
            ]
        )
        if not vencidos:
            return
        activity_type = self.env.ref("mail.mail_activity_data_todo")
        summary = _("FUE vencido (30+ días sin entrega)")
        responsable = self.env.ref("insa_reparto.group_supervisor").users[:1]
        for partner in vencidos:
            ya_existe = self.env["mail.activity"].search_count(
                [
                    ("res_model", "=", "res.partner"),
                    ("res_id", "=", partner.id),
                    ("activity_type_id", "=", activity_type.id),
                    ("summary", "=", summary),
                ]
            )
            if ya_existe:
                continue
            partner.activity_schedule(
                "mail.mail_activity_data_todo",
                summary=summary,
                note=_(
                    "Umbral fijo de 30 días confirmado por el cliente. "
                    "Canal de notificación real (push/email/WhatsApp) "
                    "sin confirmar todavía."
                ),
                user_id=(responsable.id if responsable else self.env.user.id),
            )

    @api.model_create_multi
    def create(self, vals_list):
        partners = super().create(vals_list)
        # Bug encontrado en el Paso 2.6 (mismo que en _cron_check_fue de
        # arriba): type == "fsm_location" nunca matchea un cliente real.
        # Sin este fix, la ubicación de stock dedicada por cliente —la
        # base de todo el tracking de saldo de envases, RN 3.4 / Paso
        # 1.10— nunca se creaba para ningún cliente real.
        partners.filtered(lambda p: p.customer_rank > 0)._insa_crear_ubicacion_stock()
        return partners

    def write(self, vals):
        res = super().write(vals)
        if "customer_rank" in vals:
            self.filtered(lambda p: p.customer_rank > 0)._insa_crear_ubicacion_stock()
        return res

    def _insa_crear_ubicacion_stock(self):
        """Crea una stock.location dedicada por cliente y la asigna como
        property_stock_customer, para poder trazar el saldo de envases
        de cada cliente por separado (en vez de compartir la ubicación
        genérica "Customers")."""
        parent = self.env.ref("stock.stock_location_customers")
        for partner in self:
            if partner.insa_ubicacion_stock_creada:
                continue
            location = self.env["stock.location"].create(
                {
                    "name": partner.name,
                    "usage": "customer",
                    "location_id": parent.id,
                }
            )
            partner.property_stock_customer = location.id
            partner.insa_ubicacion_stock_creada = True
