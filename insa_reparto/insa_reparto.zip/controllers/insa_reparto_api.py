# Copyright 2026 Olpa Group
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)
"""API REST para la app de reparto (D3).

El handshake de autenticación (login + verificación de token) más el
primer endpoint de datos: la hoja de ruta del día (/insa/api/hoja-de-ruta).
El resto de los endpoints de datos (control de playa, registrar visita,
etc.) siguen fuera de este alcance; se agregan reusando
_require_credencial() de acá.

auth="public": no hay usuario Odoo detrás. El aislamiento de datos es
responsabilidad de cada endpoint, resolviendo siempre el route_id desde
la credencial verificada del token — nunca desde lo que mande el cliente.
"""
import json
from datetime import date

from odoo import fields, http
from odoo.exceptions import AccessDenied, UserError, ValidationError
from odoo.http import request


class InsaRepartoAPIController(http.Controller):

    def _json_response(self, data, status=200):
        return request.make_json_response(data, status=status)

    def _get_body(self):
        try:
            return json.loads(request.httprequest.data or b"{}")
        except ValueError:
            return {}

    def _require_credencial(self):
        """Devuelve la insa.repartidor.credencial del token Bearer, o
        None si no hay token o es inválido/expirado/revocado."""
        auth_header = request.httprequest.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return None
        token = auth_header[len("Bearer "):]
        Cred = request.env["insa.repartidor.credencial"].sudo()
        try:
            return Cred.verify_token(token)
        except UserError:
            return None

    @http.route(
        "/insa/api/login", type="http", auth="public", methods=["POST"], csrf=False
    )
    def login(self, **kw):
        body = self._get_body()
        Cred = request.env["insa.repartidor.credencial"].sudo()
        try:
            cred = Cred._authenticate(body.get("login"), body.get("password"))
        except UserError as e:
            return self._json_response({"error": str(e)}, status=401)
        token = cred.generate_token()
        return self._json_response(
            {
                "token": token,
                "expira_en_horas": 24,
                "reparto": {
                    "route_id": cred.route_id.id,
                    "numero_reparto": cred.route_id.numero_reparto,
                    "login": cred.login,
                },
            }
        )

    @http.route(
        "/insa/api/whoami", type="http", auth="public", methods=["GET"], csrf=False
    )
    def whoami(self, **kw):
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)
        return self._json_response(
            {
                "route_id": cred.route_id.id,
                "numero_reparto": cred.route_id.numero_reparto,
                "login": cred.login,
                "last_login": cred.last_login.isoformat() if cred.last_login else None,
                # Paso 1.16 / supuesto 0.6: Dispensers/Repuestos son D2,
                # fuera de alcance de D1 (README del módulo). Apagado por
                # defecto — la app usa esto para decidir si muestra esas
                # tabs en ControlDePlayaDialog (Paso 2.12).
                "feature_dispensers_repuestos": (
                    request.env["ir.config_parameter"]
                    .sudo()
                    .get_param("insa_reparto.feature_dispensers_repuestos_d1", "0")
                    == "1"
                ),
            }
        )

    @http.route(
        "/insa/api/catalogo",
        type="http",
        auth="public",
        methods=["GET"],
        csrf=False,
    )
    def catalogo(self, **kw):
        """Catálogo de productos elegibles para control de playa — mismo
        domain que ya usa insa.control.playa.linea.product_id
        (visible_control_playa=True). Faltaba: el doc D1 lista "catálogo
        de artículos" como parte del payload esperado, y el selector de
        artículos de ControlDePlayaDialog (Paso 2.2) no tiene otra forma
        de saber qué productos existen."""
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        productos = (
            request.env["product.template"]
            .sudo()
            .search([("visible_control_playa", "=", True)])
        )
        return self._json_response(
            {
                "productos": [
                    {
                        "product_id": p.id,
                        "nombre": p.name,
                        "es_retornable": p.es_retornable,
                        "es_envase": p.es_envase,
                    }
                    for p in productos
                ]
            }
        )

    @http.route(
        "/insa/api/clientes/buscar",
        type="http",
        auth="public",
        methods=["GET"],
        csrf=False,
    )
    def buscar_clientes(self, **kw):
        """Paso 2.6 (Buscador modo 2): busca clientes de reparto por nombre,
        sin importar si están en la hoja de ruta de hoy — a diferencia de
        GET /insa/api/hoja-de-ruta, que siempre está anclado a
        hoja.order_ids del día. `?q=texto`, mínimo 2 caracteres."""
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        q = (kw.get("q") or "").strip()
        if len(q) < 2:
            return self._json_response({"clientes": []})

        # customer_rank > 0, no type == "fsm_location": verificado contra
        # datos reales (Docker) que los clientes de reparto son partners
        # type='contact' con customer_rank=1 — "fsm_location" es el tipo
        # que OCA fieldservice usa para el partner de la *ubicación*, no
        # del cliente. Ver hallazgo del Paso 2.6 (res_partner.py y el cron
        # de FUE del Paso 1.12 puede que tengan el mismo problema).
        partners = (
            request.env["res.partner"]
            .sudo()
            .search(
                [("customer_rank", ">", 0), ("name", "ilike", q)],
                limit=20,
            )
        )
        return self._json_response(
            {
                "clientes": [
                    {
                        "partner_id": p.id,
                        "nombre": p.name,
                        "direccion": ", ".join(filter(None, [p.street, p.city])),
                        "saldo_facturas": p.credit,
                        "consumos": p.total_invoiced,
                    }
                    for p in partners
                ]
            }
        )

    @http.route(
        "/insa/api/ciudades",
        type="http",
        auth="public",
        methods=["GET"],
        csrf=False,
    )
    def ciudades(self, **kw):
        """Alta rápida desde la app (Paso 2.7): lista de insa.city para
        poblar el selector, mismos modelos que el formulario público de
        alta (feature-formulario-alta)."""
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        ciudades = request.env["insa.city"].sudo().search([])
        return self._json_response(
            {"ciudades": [{"city_id": c.id, "nombre": c.name} for c in ciudades]}
        )

    @http.route(
        "/insa/api/calles",
        type="http",
        auth="public",
        methods=["GET"],
        csrf=False,
    )
    def calles(self, **kw):
        """Paso 2.7: calles de una ciudad puntual — filtrado en el
        servidor (`?city_id=X`), no se baja la tabla completa al celular."""
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        city_id = kw.get("city_id")
        if not city_id:
            return self._json_response({"error": "Falta 'city_id'."}, status=400)

        calles = (
            request.env["insa.street"]
            .sudo()
            .search([("city_id", "=", int(city_id))])
        )
        return self._json_response(
            {"calles": [{"street_id": c.id, "nombre": c.name} for c in calles]}
        )

    @http.route(
        "/insa/api/clientes",
        type="http",
        auth="public",
        methods=["POST"],
        csrf=False,
    )
    def crear_cliente(self, **kw):
        """Alta rápida desde la app (Paso 2.7). A diferencia del
        formulario público (feature-formulario-alta, que deja el contacto
        como lead sin tocar customer_rank), acá SÍ se marca
        customer_rank=1 al crear: la app solo la usan repartidores
        autenticados con la credencial de su ruta — a diferencia del
        formulario web, abierto a cualquiera — así que el cliente queda
        utilizable de inmediato (Buscador, registrar una visita), en vez
        de esperar revisión de INSA. Dispara la creación de su ubicación
        de stock (ver res_partner.py, create()).
        """
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        body = self._get_body()
        nombre = (body.get("nombre") or "").strip()
        city_id = body.get("city_id")
        street_id = body.get("street_id")
        street_number = (body.get("street_number") or "").strip()
        if not nombre or not city_id or not street_id or not street_number:
            return self._json_response(
                {"error": "Faltan 'nombre', 'city_id', 'street_id' o 'street_number'."},
                status=400,
            )

        city = request.env["insa.city"].sudo().browse(int(city_id))
        street = request.env["insa.street"].sudo().browse(int(street_id))
        if not city.exists() or not street.exists():
            return self._json_response(
                {"error": "Ciudad o calle inexistente."}, status=400
            )

        mobile = (body.get("mobile") or "").strip()
        street_display = f"{street.name} {street_number}".strip()

        partner = request.env["res.partner"].sudo().create(
            {
                "name": nombre,
                "mobile": mobile or False,
                "street": street_display,
                "city": city.name,
                "customer_rank": 1,
                "insa_city_id": city.id,
                "insa_street_id": street.id,
                "insa_street_number": street_number,
                "insa_floor": body.get("floor") or False,
                "insa_apartment": body.get("apartment") or False,
                "insa_tower": body.get("tower") or False,
                "insa_block": body.get("block") or False,
                "insa_lot": body.get("lot") or False,
                "insa_address_notes": body.get("address_notes") or False,
                "insa_tax_condition": body.get("tax_condition") or "consumidor_final",
                "insa_order_notes": body.get("order_notes") or False,
            }
        )
        return self._json_response(
            {
                "partner_id": partner.id,
                "nombre": partner.name,
                "direccion": ", ".join(filter(None, [partner.street, partner.city])),
                "saldo_facturas": partner.credit,
                "consumos": partner.total_invoiced,
            }
        )

    @http.route(
        "/insa/api/hoja-de-ruta",
        type="http",
        auth="public",
        methods=["GET"],
        csrf=False,
    )
    def hoja_de_ruta(self, **kw):
        """Primer endpoint de datos D3 más allá de login/whoami: la hoja de
        ruta del día de la ruta del token (nunca de un route_id que mande
        el cliente) con su lista de clientes a visitar.

        `?date=YYYY-MM-DD` (default: hoy). Sin hoja de ruta para esa
        fecha/ruta: 200 con `hoja_ruta: null`, no 404 — es un estado
        esperado (todavía no se armó/asignó), no un error.

        Clientes = fsm.order (OCA, "parada agendada hoy") de
        `hoja.order_ids`, cruzados con insa.movimiento.cliente (la visita
        ya registrada, si la hay) para el estado visitado/resultado/cobro,
        más insa.pedido.extra de `hoja.pedido_extra_ids` (supuesto 0.3),
        marcados con `es_extra: true` para que la app los distinga
        visualmente de las paradas regulares del día.
        saldo_facturas/consumos salen de res.partner (credit/total_invoiced,
        reales de account/sale). fecha_ultima_entrega/fecha_ultima_cobranza
        (Paso 1.12) son ahora campos dedicados y persistidos en
        res.partner (antes se calculaban on-the-fly en cada request).
        """
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        date_str = kw.get("date") or date.today().isoformat()
        try:
            fecha = date.fromisoformat(date_str)
        except ValueError:
            return self._json_response(
                {"error": "Parámetro 'date' inválido, formato esperado YYYY-MM-DD."},
                status=400,
            )

        Dayroute = request.env["fsm.route.dayroute"].sudo()
        hoja = Dayroute.search(
            [("route_id", "=", cred.route_id.id), ("date", "=", fecha)], limit=1
        )
        if not hoja:
            return self._json_response({"hoja_ruta": None, "clientes": []})

        clientes = [self._serializar_cliente(hoja, order) for order in hoja.order_ids]
        clientes += [
            self._serializar_pedido_extra(pedido) for pedido in hoja.pedido_extra_ids
        ]
        # Paso 2.6 (Buscador modo 2): ventas puntuales a clientes fuera de
        # la hoja de ruta de hoy — sin esto, quedarían guardadas en Odoo
        # pero invisibles en la app después de cargarlas.
        partners_en_ruta = hoja.order_ids.mapped("location_id.partner_id")
        movimientos_fuera_de_ruta = hoja.movimiento_cliente_ids.filtered(
            lambda m: m.partner_id not in partners_en_ruta
        )
        clientes += [
            self._serializar_movimiento_fuera_de_ruta(mov) for mov in movimientos_fuera_de_ruta
        ]
        return self._json_response(
            {
                "hoja_ruta": {
                    "id": hoja.id,
                    "date": str(hoja.date),
                    "state": hoja.state,
                    "reparto_numero": hoja.reparto_numero,
                },
                "clientes": clientes,
                # Paso 1.12 (FUC): umbral configurable, no hardcodeado en
                # la app — reemplaza el corte fijo saldoFacturas > 30000
                # que hoy vive en el cliente TS (Paso 2.10). Default 30000
                # para no cambiar el comportamiento actual hasta que se
                # reconfigure a propósito.
                "fuc_umbral_saldo": float(
                    request.env["ir.config_parameter"]
                    .sudo()
                    .get_param("insa_reparto.fuc_umbral_saldo", "30000")
                ),
            }
        )

    @http.route(
        "/insa/api/visita",
        type="http",
        auth="public",
        methods=["POST"],
        csrf=False,
    )
    def registrar_visita(self, **kw):
        """Crea o actualiza el insa.movimiento.cliente de un cliente en la
        hoja de ruta del día. Upsert (no siempre-crear): GET /hoja-de-ruta
        ya asume "un movimiento por cliente por hoja"
        (`movimiento_cliente_ids.filtered(partner)[:1]`), así que un
        segundo POST para el mismo cliente/hoja actualiza el existente en
        vez de duplicarlo.

        No confirma movimientos de stock de envase (action_confirmar):
        eso sigue siendo un paso aparte, igual que en el form web.
        """
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        body = self._get_body()
        partner_id = body.get("partner_id")
        if not partner_id:
            return self._json_response({"error": "Falta 'partner_id'."}, status=400)

        date_str = body.get("date") or date.today().isoformat()
        try:
            fecha = date.fromisoformat(date_str)
        except ValueError:
            return self._json_response(
                {"error": "Parámetro 'date' inválido, formato esperado YYYY-MM-DD."},
                status=400,
            )

        Dayroute = request.env["fsm.route.dayroute"].sudo()
        hoja = Dayroute.search(
            [("route_id", "=", cred.route_id.id), ("date", "=", fecha)], limit=1
        )
        if not hoja:
            return self._json_response(
                {"error": "No hay hoja de ruta para esta ruta en esa fecha."},
                status=404,
            )
        if hoja.state != "en_reparto":
            return self._json_response(
                {
                    "error": "La hoja de ruta no está 'En reparto', no se "
                    "puede registrar la visita."
                },
                status=400,
            )

        partner = request.env["res.partner"].sudo().browse(int(partner_id))
        if not partner.exists():
            return self._json_response({"error": "Cliente inexistente."}, status=400)

        order = hoja.order_ids.filtered(
            lambda o, p=partner: o.location_id.partner_id == p
        )[:1]
        # Paso 2.6 (Buscador modo 2): un cliente fuera de la hoja de ruta
        # de hoy también puede recibir una visita/venta puntual — ya no se
        # rechaza de plano, solo se exige que sea un cliente real
        # (customer_rank > 0, mismo criterio que /insa/api/clientes/buscar
        # — no type == "fsm_location", que es el tipo que OCA fieldservice
        # usa para el partner de la ubicación, no del cliente).
        if not order and partner.customer_rank <= 0:
            return self._json_response(
                {"error": "El cliente no es un punto de entrega válido."},
                status=400,
            )

        mov = hoja.movimiento_cliente_ids.filtered(
            lambda m, p=partner: m.partner_id == p
        )[:1]
        vals = {
            "hoja_ruta_id": hoja.id,
            "partner_id": partner.id,
            "resultado": body.get("resultado") or False,
            "cobro_efectivo": body.get("cobro_efectivo") or 0.0,
        }
        if "visitado" in body:
            vals["visitado"] = bool(body.get("visitado"))

        try:
            if mov:
                mov.write(vals)
            else:
                mov = request.env["insa.movimiento.cliente"].sudo().create(vals)

            if "lineas_articulo" in body:
                mov.linea_articulo_ids.unlink()
                for linea in body.get("lineas_articulo") or []:
                    request.env["insa.movimiento.cliente.linea.articulo"].sudo().create(
                        {
                            "movimiento_id": mov.id,
                            "product_id": linea.get("product_id"),
                            "tipo": linea.get("tipo") or "venta",
                            "cantidad": linea.get("cantidad", 1.0),
                            "precio_unitario": linea.get("precio_unitario", 0.0),
                        }
                    )
            if "lineas_envase" in body:
                mov.linea_envase_ids.unlink()
                for linea in body.get("lineas_envase") or []:
                    request.env["insa.movimiento.cliente.linea.envase"].sudo().create(
                        {
                            "movimiento_id": mov.id,
                            "product_id": linea.get("product_id"),
                            "tipo": linea.get("tipo"),
                            "cantidad": linea.get("cantidad", 1.0),
                        }
                    )
        except UserError as e:
            return self._json_response({"error": str(e)}, status=400)

        if order:
            return self._json_response(self._serializar_cliente(hoja, order))
        return self._json_response(self._serializar_movimiento_fuera_de_ruta(mov))

    def _serializar_cliente(self, hoja, order):
        partner = order.location_id.partner_id
        mov = hoja.movimiento_cliente_ids.filtered(
            lambda m, p=partner: m.partner_id == p
        )[:1]
        return {
            "partner_id": partner.id,
            "nombre": partner.name,
            "direccion": ", ".join(filter(None, [partner.street, partner.city])),
            "saldo_facturas": partner.credit,
            "consumos": partner.total_invoiced,
            "fecha_ultima_entrega": (
                partner.fecha_ultima_entrega.isoformat()
                if partner.fecha_ultima_entrega
                else None
            ),
            "fecha_ultima_cobranza": (
                partner.fecha_ultima_cobranza.isoformat()
                if partner.fecha_ultima_cobranza
                else None
            ),
            # Supuesto 0.2 / RN textual de Nicolás: "pendiente" es "ningún
            # movimiento cargado", cualquiera sea su tipo. No usar
            # mov.visitado acá: ese campo es un concepto distinto (RN-18,
            # "hubo visita física") que puede ser False a propósito en un
            # sin_gestion resuelto por WhatsApp sin ir al domicilio, y ese
            # caso también debe salir de "Pendientes" en la app.
            "visitado": bool(mov),
            "resultado": mov.resultado or None if mov else None,
            "cobro_efectivo": mov.cobro_efectivo if mov else 0.0,
            "iconos_visita": (mov.iconos_visita or "") if mov else "",
            "es_extra": False,
            "pedido_extra_id": None,
            "fuera_de_ruta": False,
            "deuda_envases": self._deuda_envases(partner),
        }

    def _serializar_movimiento_fuera_de_ruta(self, mov):
        # Paso 2.6 (Buscador modo 2): un insa.movimiento.cliente cuyo
        # partner no está en hoja.order_ids — venta puntual a un cliente
        # fuera de la hoja de ruta de hoy. Distinto de es_extra
        # (insa.pedido.extra, inyectado por administración, RN-17): acá no
        # hay pedido previo, el repartidor lo encontró con el buscador y le
        # cargó la visita directamente.
        partner = mov.partner_id
        return {
            "partner_id": partner.id,
            "nombre": partner.name,
            "direccion": ", ".join(filter(None, [partner.street, partner.city])),
            "saldo_facturas": partner.credit,
            "consumos": partner.total_invoiced,
            "fecha_ultima_entrega": (
                partner.fecha_ultima_entrega.isoformat()
                if partner.fecha_ultima_entrega
                else None
            ),
            "fecha_ultima_cobranza": (
                partner.fecha_ultima_cobranza.isoformat()
                if partner.fecha_ultima_cobranza
                else None
            ),
            "visitado": True,
            "resultado": mov.resultado or None,
            "cobro_efectivo": mov.cobro_efectivo,
            "iconos_visita": mov.iconos_visita or "",
            "es_extra": False,
            "pedido_extra_id": None,
            "fuera_de_ruta": True,
            "deuda_envases": self._deuda_envases(partner),
        }

    def _deuda_envases(self, partner):
        # Paso 1.10 / RN 3.4 del doc D1: "la app le muestra al repartidor,
        # antes de la visita, los clientes con deuda de envases para que
        # los reclame". Solo los que tienen algo por recuperar.
        saldos = (
            request.env["insa.saldo.envase"]
            .sudo()
            .search(
                [
                    ("partner_id", "=", partner.id),
                    ("cantidad_a_recuperar", ">", 0),
                ]
            )
        )
        return [
            {
                "product_id": saldo.product_id.id,
                "producto": saldo.product_id.name,
                "saldo": saldo.saldo,
                "permitido": saldo.permitido,
                "cantidad_a_recuperar": saldo.cantidad_a_recuperar,
            }
            for saldo in saldos
        ]

    def _serializar_pedido_extra(self, pedido):
        # Supuesto 0.3: mismo shape base que un cliente regular +
        # es_extra/pedido_extra_id para que la app lo distinga
        # visualmente (RN-17, "la flechita roja"). "visitado" reusa
        # `atendido` para que el filtro Pendientes/Todos de la app
        # funcione igual sobre ambas listas sin lógica aparte.
        partner = pedido.partner_id
        return {
            "partner_id": partner.id,
            "nombre": partner.name,
            "direccion": ", ".join(filter(None, [partner.street, partner.city])),
            "saldo_facturas": partner.credit,
            "consumos": partner.total_invoiced,
            "fecha_ultima_entrega": (
                partner.fecha_ultima_entrega.isoformat()
                if partner.fecha_ultima_entrega
                else None
            ),
            "fecha_ultima_cobranza": (
                partner.fecha_ultima_cobranza.isoformat()
                if partner.fecha_ultima_cobranza
                else None
            ),
            "visitado": bool(pedido.atendido),
            "resultado": None,
            "cobro_efectivo": 0.0,
            "iconos_visita": "",
            "es_extra": True,
            "pedido_extra_id": pedido.id,
            "fuera_de_ruta": False,
            "deuda_envases": self._deuda_envases(partner),
            "nota": pedido.nota or "",
            "articulos_solicitados": [
                {
                    "product_id": linea.product_id.id,
                    "producto": linea.product_id.name,
                    "cantidad": linea.cantidad,
                }
                for linea in pedido.linea_ids
            ],
        }

    @http.route(
        "/insa/api/control-playa",
        type="http",
        auth="public",
        methods=["GET"],
        csrf=False,
    )
    def control_playa(self, **kw):
        """Paso 1.6: lee el control de playa de salida y entrada de la
        hoja de ruta del día de la ruta del token."""
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        date_str = kw.get("date") or date.today().isoformat()
        try:
            fecha = date.fromisoformat(date_str)
        except ValueError:
            return self._json_response(
                {"error": "Parámetro 'date' inválido, formato esperado YYYY-MM-DD."},
                status=400,
            )

        hoja = (
            request.env["fsm.route.dayroute"]
            .sudo()
            .search([("route_id", "=", cred.route_id.id), ("date", "=", fecha)], limit=1)
        )
        if not hoja:
            return self._json_response({"salida": None, "entrada": None})

        salida = hoja.control_playa_ids.filtered(lambda c: c.tipo == "salida")[:1]
        entrada = hoja.control_playa_ids.filtered(lambda c: c.tipo == "entrada")[:1]
        return self._json_response(
            {
                "salida": self._serializar_control_playa(salida) if salida else None,
                "entrada": self._serializar_control_playa(entrada) if entrada else None,
            }
        )

    @http.route(
        "/insa/api/control-playa",
        type="http",
        auth="public",
        methods=["POST"],
        csrf=False,
    )
    def registrar_control_playa(self, **kw):
        """Paso 1.6: crea o actualiza (upsert por tipo, ver
        hoja_ruta_tipo_unique en insa.control.playa) el control de playa
        de salida o entrada de la hoja de ruta del día.

        Gateo de estado: salida se acepta en 'borrador' (crearla con
        líneas es lo que dispara el pase a 'en_reparto', ver
        _maybe_iniciar_reparto) o ya en 'en_reparto'; entrada solo en
        'en_reparto' (no antes de que arranque el reparto, no después de
        action_registrar_caja)."""
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        body = self._get_body()
        tipo = body.get("tipo")
        if tipo not in ("salida", "entrada"):
            return self._json_response(
                {"error": "'tipo' debe ser 'salida' o 'entrada'."}, status=400
            )

        date_str = body.get("date") or date.today().isoformat()
        try:
            fecha = date.fromisoformat(date_str)
        except ValueError:
            return self._json_response(
                {"error": "Parámetro 'date' inválido, formato esperado YYYY-MM-DD."},
                status=400,
            )

        Dayroute = request.env["fsm.route.dayroute"].sudo()
        hoja = Dayroute.search(
            [("route_id", "=", cred.route_id.id), ("date", "=", fecha)], limit=1
        )
        if not hoja:
            return self._json_response(
                {"error": "No hay hoja de ruta para esta ruta en esa fecha."},
                status=404,
            )

        estados_validos = {
            "salida": ("borrador", "en_reparto"),
            "entrada": ("en_reparto",),
        }
        if hoja.state not in estados_validos[tipo]:
            return self._json_response(
                {
                    "error": "No se puede registrar el control de playa de "
                    f"{tipo} con la hoja de ruta en estado '{hoja.state}'."
                },
                status=400,
            )

        control = hoja.control_playa_ids.filtered(lambda c, t=tipo: c.tipo == t)[:1]
        vals = {
            "hoja_ruta_id": hoja.id,
            "tipo": tipo,
            "kilometros": body.get("kilometros") or 0.0,
        }

        try:
            if control:
                control.write(vals)
            else:
                control = request.env["insa.control.playa"].sudo().create(vals)

            if "lineas" in body:
                control.linea_ids.unlink()
                for linea in body.get("lineas") or []:
                    request.env["insa.control.playa.linea"].sudo().create(
                        {
                            "control_playa_id": control.id,
                            "product_id": linea.get("product_id"),
                            "cantidad": linea.get("cantidad", 0.0),
                            "cantidad_vacia": linea.get("cantidad_vacia", 0.0),
                        }
                    )
        except (UserError, ValidationError) as e:
            return self._json_response({"error": str(e)}, status=400)

        return self._json_response(self._serializar_control_playa(control))

    def _serializar_control_playa(self, control):
        return {
            "id": control.id,
            "tipo": control.tipo,
            "fecha_hora": control.fecha_hora.isoformat() if control.fecha_hora else None,
            "kilometros": control.kilometros,
            "aprobado": bool(control.aprobado_por_id),
            "aprobado_por": control.aprobado_por_id.name or None,
            "aprobado_fecha": (
                control.aprobado_fecha.isoformat() if control.aprobado_fecha else None
            ),
            "lineas": [
                {
                    "product_id": linea.product_id.id,
                    "producto": linea.product_id.name,
                    "cantidad": linea.cantidad,
                    "cantidad_vacia": linea.cantidad_vacia,
                }
                for linea in control.linea_ids
            ],
        }

    @http.route(
        "/insa/api/control-playa/aprobar",
        type="http",
        auth="public",
        methods=["POST"],
        csrf=False,
    )
    def aprobar_control_playa(self, **kw):
        """Paso 1.7 (supuesto 0.1, 🔴 riesgo alto — sin confirmar con el
        cliente todavía, ver "Preguntas para el cliente" del plan de
        trabajo). Segundo factor de aprobación: requiere el Bearer token
        de la ruta (primer factor, ya lo exige _require_credencial, "este
        dispositivo es del reparto tal") MÁS login/password de un usuario
        real de res.users con el grupo group_controlador (segundo factor,
        "esta persona es controladora"). insa.repartidor.credencial sigue
        siendo, sin cambios, el mecanismo de acceso del repartidor a la
        app — esto no lo reemplaza ni lo toca, es una verificación
        adicional sobre un control de playa puntual.

        Usa res.users.authenticate(), no execute_kw ni sesión Odoo: valida
        la contraseña y devuelve el uid, sin dar acceso genérico a Odoo
        desde la app.
        """
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        body = self._get_body()
        tipo = body.get("tipo")
        login = body.get("login")
        password = body.get("password")
        if tipo not in ("salida", "entrada") or not login or not password:
            return self._json_response(
                {"error": "Faltan 'tipo' ('salida'/'entrada'), 'login' o 'password'."},
                status=400,
            )

        date_str = body.get("date") or date.today().isoformat()
        try:
            fecha = date.fromisoformat(date_str)
        except ValueError:
            return self._json_response(
                {"error": "Parámetro 'date' inválido, formato esperado YYYY-MM-DD."},
                status=400,
            )

        hoja = (
            request.env["fsm.route.dayroute"]
            .sudo()
            .search([("route_id", "=", cred.route_id.id), ("date", "=", fecha)], limit=1)
        )
        if not hoja:
            return self._json_response(
                {"error": "No hay hoja de ruta para esta ruta en esa fecha."},
                status=404,
            )

        control = hoja.control_playa_ids.filtered(lambda c, t=tipo: c.tipo == t)[:1]
        if not control:
            return self._json_response(
                {"error": f"No hay control de playa de {tipo} para aprobar."},
                status=404,
            )

        try:
            auth_info = request.env["res.users"].sudo().authenticate(
                request.db,
                {"type": "password", "login": login, "password": password},
                {"interactive": False},
            )
        except AccessDenied:
            return self._json_response(
                {"error": "Usuario o contraseña incorrectos."}, status=401
            )

        controlador = request.env["res.users"].sudo().browse(auth_info["uid"])
        if not controlador.has_group("insa_reparto.group_controlador"):
            return self._json_response(
                {"error": "El usuario no tiene permiso de controlador."}, status=403
            )

        control.write(
            {
                "aprobado_por_id": controlador.id,
                "aprobado_fecha": fields.Datetime.now(),
            }
        )
        return self._json_response(self._serializar_control_playa(control))

    @http.route(
        "/insa/api/liquidacion",
        type="http",
        auth="public",
        methods=["GET"],
        csrf=False,
    )
    def liquidacion(self, **kw):
        """Paso 1.9: lectura de la liquidación de la hoja de ruta del día.
        Solo lectura — los insa.liquidacion.articulo/.envase se calculan
        server-side (action_recalcular_liquidacion, disparado automático
        al pasar a 'consolidando' vía action_registrar_caja), la app no
        escribe nada acá. El color (supuesto 0.4: texto rojo, no relleno)
        es puramente visual y queda del lado de la app (Paso 2.1) — este
        endpoint solo expone los números y el signo de la diferencia."""
        cred = self._require_credencial()
        if not cred:
            return self._json_response({"error": "No autorizado."}, status=401)

        date_str = kw.get("date") or date.today().isoformat()
        try:
            fecha = date.fromisoformat(date_str)
        except ValueError:
            return self._json_response(
                {"error": "Parámetro 'date' inválido, formato esperado YYYY-MM-DD."},
                status=400,
            )

        hoja = (
            request.env["fsm.route.dayroute"]
            .sudo()
            .search([("route_id", "=", cred.route_id.id), ("date", "=", fecha)], limit=1)
        )
        if not hoja:
            return self._json_response(
                {
                    "hoja_ruta": None,
                    "disponible": False,
                    "tiene_diferencias": False,
                    "efectivo": None,
                    "articulos": [],
                    "envases": [],
                }
            )

        disponible = hoja.state in ("consolidando", "cerrada")
        return self._json_response(
            {
                "hoja_ruta": {
                    "id": hoja.id,
                    "date": str(hoja.date),
                    "state": hoja.state,
                },
                "disponible": disponible,
                "tiene_diferencias": hoja.tiene_diferencias,
                "efectivo": {
                    "total_registrado": hoja.total_efectivo_registrado,
                    "efectivo_caja_repartidor": hoja.efectivo_caja_repartidor,
                    "diferencia": hoja.diferencia_efectivo,
                },
                "articulos": [
                    {
                        "product_id": linea.product_id.id,
                        "producto": linea.product_id.name,
                        "teorico": linea.teorico,
                        "registrado": linea.registrado,
                        "diferencia": linea.diferencia,
                    }
                    for linea in hoja.liquidacion_articulo_ids
                ],
                "envases": [
                    {
                        "product_id": linea.product_id.id,
                        "producto": linea.product_id.name,
                        "entrada_teorica": linea.entrada_teorica,
                        "entrada_real": linea.entrada_real,
                        "diferencia": linea.diferencia,
                    }
                    for linea in hoja.liquidacion_envase_ids
                ],
            }
        )

